package lab3;

public interface InterestStrategy {

    double getInterest(double balance);
}
