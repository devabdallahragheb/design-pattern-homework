package lab3;

public interface Promotion {
    double promote(double balance) ;
}
